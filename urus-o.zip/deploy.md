docker login ghcr.io -u ne2adh
docker build -t ghcr.io/ne2adh/urus-o:prod .
docker push ghcr.io/ne2adh/urus-o:prod

Image Name: ghcr.io/ne2adh/urus-o:prod
