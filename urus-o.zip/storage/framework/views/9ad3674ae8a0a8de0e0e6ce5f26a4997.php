<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

    
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div class="bg-white rounded-xl shadow p-5">
            <div class="text-xs text-gray-500 mb-1">Registros hoy</div>
            <div class="text-3xl font-semibold"><?php echo e(number_format($kpis['hoy'])); ?></div>
        </div>
        <div class="bg-white rounded-xl shadow p-5">
            <div class="text-xs text-gray-500 mb-1">Registros del mes</div>
            <div class="text-3xl font-semibold"><?php echo e(number_format($kpis['mes'])); ?></div>
        </div>
        <div class="bg-white rounded-xl shadow p-5">
            <div class="text-xs text-gray-500 mb-1">Usuarios activos hoy</div>
            <div class="text-3xl font-semibold"><?php echo e(number_format($kpis['usuariosHoy'])); ?></div>
        </div>
        <div class="bg-white rounded-xl shadow p-5">
            <div class="text-xs text-gray-500 mb-1">% meta promedio (mes)</div>
            <div class="text-3xl font-semibold"><?php echo e(number_format($kpis['ratingMes'], 2)); ?>%</div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <div class="lg:col-span-2 bg-white rounded-xl shadow p-6">
            <div class="flex items-center justify-between mb-3">
                <h3 class="text-lg font-semibold">Totales por mes</h3>
                <span class="text-xs text-gray-500"><?php echo e($anioPrev); ?> vs <?php echo e($anio); ?></span>
            </div>
            <div class="h-72"> 
                <canvas id="bars"></canvas>
            </div>
        </div>


        
        <div class="bg-white rounded-xl shadow p-6">
            <h3 class="text-lg font-semibold mb-3">Avance de meta (mes)</h3>
            <div class="flex items-center gap-6">
                <div class="w-40 h-40">
                    <canvas id="donut"></canvas>
                </div>
                <div class="flex-1">
                    <ul class="text-sm space-y-2">
                        <li class="flex items-center justify-between">
                            <span class="text-gray-600">Cumplido</span>
                            <span class="font-semibold"><?php echo e(number_format($donut[0], 2)); ?>%</span>
                        </li>
                        <li class="flex items-center justify-between">
                            <span class="text-gray-600">Pendiente</span>
                            <span class="font-semibold"><?php echo e(number_format($donut[1], 2)); ?>%</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="mt-6">
                <h4 class="text-sm font-semibold mb-2">Top provincias (mes)</h4>
                <div class="space-y-2">
                    <?php $__empty_1 = true; $__currentLoopData = $topProv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center justify-between text-sm">
                            <span class="text-gray-700"><?php echo e($p->provincia); ?></span>
                            <span class="font-semibold"><?php echo e(number_format($p->t)); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-sm text-gray-500">Sin datos</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="lg:col-span-3 bg-white rounded-xl shadow p-6">
            <div class="flex items-center justify-between mb-3">
                <h3 class="text-lg font-semibold">Registros últimos 14 días</h3>
                <span class="text-xs text-gray-500">Diario</span>
            </div>
            <div class="h-72">
                <canvas id="area14"></canvas>
            </div>
        </div>
    </div>

    <script>
        const meses = <?php echo json_encode($meses, 15, 512) ?>;
        const serieActual = <?php echo json_encode($serieActual, 15, 512) ?>;
        const seriePrev = <?php echo json_encode($seriePrev, 15, 512) ?>;

        const labels14 = <?php echo json_encode($labels14, 15, 512) ?>;
        const data14 = <?php echo json_encode($data14, 15, 512) ?>;

        const donutData = <?php echo json_encode($donut, 15, 512) ?>;

        // Barras
        (function initBars(){
    const el = document.getElementById('bars');
    const prev = Chart.getChart(el);
    if (prev) prev.destroy();

    const ctx = el.getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: meses,
        datasets: [
          { label: '<?php echo e($anioPrev); ?>', data: seriePrev },
          { label: '<?php echo e($anio); ?>', data: serieActual }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false, // respeta la altura del contenedor
        scales: { y: { beginAtZero: true } },
        plugins: { legend: { position: 'top' } }
      }
    });
  })();

        // Donut
        new Chart(document.getElementById('donut'), {
            type: 'doughnut',
            data: {
                labels: ['Cumplido', 'Pendiente'],
                datasets: [{
                    data: donutData
                }]
            },
            options: {
                cutout: '65%',
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Área 14 días
        (function initArea14(){
            const el = document.getElementById('area14');
            const prev = Chart.getChart(el);
            if (prev) prev.destroy();

            const ctx = el.getContext('2d');
            new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($labels14, 15, 512) ?>,
                datasets: [{
                label: 'Total día',
                data: <?php echo json_encode($data14, 15, 512) ?>,
                fill: true,
                tension: 0.35,
                pointRadius: 2,
                borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                spanGaps: true,
                scales: { y: { beginAtZero: true } },
                plugins: { legend: { display: false } },
                animation: false
            }
            });
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROYECTOS\urus\resources\views/dashboard.blade.php ENDPATH**/ ?>