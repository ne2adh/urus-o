<?php
    /** @var \App\Models\User|null $usuario */
?>
<div class="space-y-4">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium mb-1">Username *</label>
            <input type="text" name="username" value="<?php echo e(old('username', $usuario->username ?? '')); ?>" required
                class="w-full border rounded px-3 py-2 focus:outline-none focus:ring">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">CI *</label>
            <input type="text" name="ci" value="<?php echo e(old('ci', $usuario->ci ?? '')); ?>" required
                class="w-full border rounded px-3 py-2 focus:outline-none focus:ring">
        </div>
    </div>

    <div>
        <label class="block text-sm font-medium mb-1">Nombre completo *</label>
        <input type="text" name="nombre_completo"
            value="<?php echo e(old('nombre_completo', $usuario->nombre_completo ?? '')); ?>" required
            class="w-full border rounded px-3 py-2 focus:outline-none focus:ring">
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium mb-1">Email</label>
            <input type="email" name="email" value="<?php echo e(old('email', $usuario->email ?? '')); ?>"
                class="w-full border rounded px-3 py-2 focus:outline-none focus:ring">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Nombre (alias)</label>
            <input type="text" name="name" value="<?php echo e(old('name', $usuario->name ?? '')); ?>"
                class="w-full border rounded px-3 py-2 focus:outline-none focus:ring">
        </div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <label class="block text-sm font-medium mb-1">Rol *</label>
        <select name="rol" required class="w-full border rounded px-3 py-2 focus:outline-none focus:ring">
            <?php $roles = ['jefe'=>'Jefe','tecnico'=>'Técnico','superadministrador'=>'Superadministrador']; ?>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($val); ?>" <?php if(old('rol', $usuario->rol ?? '') === $val): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium mb-1">
                Contraseña <?php echo e(isset($usuario) ? '(dejar vacío para no cambiar)' : '*'); ?>

            </label>
            <input type="password" name="password"
                class="w-full border rounded px-3 py-2 focus:outline-none focus:ring">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">
                Confirmar contraseña <?php echo e(isset($usuario) ? '' : '*'); ?>

            </label>
            <input type="password" name="password_confirmation"
                class="w-full border rounded px-3 py-2 focus:outline-none focus:ring">
        </div>
    </div>
</div>
<?php /**PATH D:\PROYECTOS\urus\resources\views/usuarios/_form.blade.php ENDPATH**/ ?>