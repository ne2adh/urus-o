<?php $__env->startSection('title', 'Editar usuario'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl">
  <h1 class="text-2xl font-semibold mb-6">Editar usuario #<?php echo e($usuario->id); ?></h1>

  <form action="<?php echo e(route('usuarios.update', $usuario)); ?>" method="POST" class="bg-white p-6 rounded shadow space-y-6">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <?php echo $__env->make('usuarios._form', ['usuario' => $usuario], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="flex items-center gap-2">
      <a href="<?php echo e(route('usuarios.index')); ?>" class="px-4 py-2 rounded border">Cancelar</a>
      <button class="px-4 py-2 rounded bg-amber-500 text-white hover:bg-amber-600">Actualizar</button>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROYECTOS\urus\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>