<?php $__env->startSection('title', 'Crear usuario'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl">
  <h1 class="text-2xl font-semibold mb-6">Crear usuario</h1>

  <form action="<?php echo e(route('usuarios.store')); ?>" method="POST" class="bg-white p-6 rounded shadow space-y-6">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('usuarios._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="flex items-center gap-2">
      <a href="<?php echo e(route('usuarios.index')); ?>" class="px-4 py-2 rounded border">Cancelar</a>
      <button class="px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700">Guardar</button>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROYECTOS\urus\resources\views/usuarios/create.blade.php ENDPATH**/ ?>