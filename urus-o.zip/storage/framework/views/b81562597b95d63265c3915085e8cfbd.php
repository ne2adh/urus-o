<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2"></script>
    
    <div class="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6">
        <div class="bg-white rounded-xl shadow p-5">
            <div class="text-lg font-semibold text-blue-500 mb-1">TOTAL META</div>
            <div class="text-3xl font-semibold">6000</div>
        </div>
        <div class="bg-white rounded-xl shadow p-5">
            <div class="text-lg font-semibold text-yellow-500 mb-1">TOTAL RESTANTE</div>
            <div class="text-3xl font-semibold"><?php echo e(number_format($kpis['totalGlobal2'])); ?></div>
        </div>
        <div class="bg-white rounded-xl shadow p-5">
            <div class="text-lg text-orange-500 mb-1">TOTAL DEL DÍA</div>
            <div class="text-3xl font-semibold"><?php echo e(number_format($kpis['totalHoy'])); ?></div>
        </div>
        <div class="bg-white rounded-xl shadow p-5">
            <div class="text-lg text-red-500 mb-1">TOTAL ACUMULADO</div>
            <div class="text-3xl font-semibold text-green-400"><?php echo e(number_format($kpis['totalGlobal'])); ?></div>
        </div>
        
    </div>


        <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2"></script>
        
        <div class="col-span-full bg-white rounded-xl shadow p-6 mt-3">
            <h3 class="text-lg font-semibold mb-4">Metas por Provincia</h3>
            <div class="overflow-x-auto">
                <table class="min-w-full text-xs sm:text-sm">
                    <thead class="bg-slate-100">
                        <tr>
                            <th class="px-3 py-2 text-left">PROVINCIA</th>
                            <th class="px-3 py-2 text-right">HABILITADO</th>
                            <th class="px-3 py-2 text-right">REQUERIDO</th>
                            <th class="px-3 py-2 text-right">REGISTRADO</th>
                            <th class="px-3 py-2 text-right">RESTANTE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tablaExcel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-t">
                                <td class="px-3 py-2"><?php echo e($r['provincia']); ?></td>
                                <td class="px-3 py-2 text-right"><?php echo e(number_format($r['habilitado'])); ?></td>
                                <td class="px-3 py-2 text-right"><?php echo e(number_format($r['requerido'])); ?></td>
                                <td class="px-3 py-2 text-right"><?php echo e(number_format($r['registrado'])); ?></td>
                                <td class="px-3 py-2 text-right">
                                    <span class="px-2 py-0.5 rounded text-black bg-green-200">
                                        <?php echo e(number_format($r['restante'])); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="bg-slate-50">
                        <tr class="font-semibold border-t">
                            <td class="px-3 py-2">TOTALES</td>
                            <td class="px-3 py-2 text-right"><?php echo e(number_format($totalesExcel['habilitado'])); ?></td>
                            <td class="px-3 py-2 text-right"><?php echo e(number_format($totalesExcel['requerido'])); ?></td>
                            <td class="px-3 py-2 text-right"><?php echo e(number_format($totalesExcel['registrado'])); ?></td>
                            <td class="px-3 py-2 text-right"><?php echo e(number_format($totalesExcel['restante'])); ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    
    <div class="col-span-full bg-white rounded-xl shadow p-6 mt-6">
        <h3 class="text-lg font-semibold mb-4">Avance por provincia (Requerido vs Registrado)</h3>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
            <?php $__currentLoopData = $piesExcel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $req = (int) $p['requerido'];
                    $reg = (int) $p['registrado'];
                    $rest = (int) $p['pendiente'];
                    $regPct = $req > 0 ? round(($reg / $req) * 100) : 0;
                    $restPct = max(0, 100 - $regPct);
                    $slug = \Illuminate\Support\Str::slug($p['provincia'], '-');
                ?>

                <div class="bg-slate-50 rounded-xl p-4 shadow-sm flex flex-col items-center">
                    <h4 class="font-semibold mb-2 text-center"><?php echo e(strtoupper($p['provincia'])); ?></h4>

                    <div class="w-40 h-40">
                        <canvas id="pie-<?php echo e($slug); ?>"></canvas>
                    </div>

                    <div class="mt-3 text-xs text-gray-700 space-y-1 text-center">
                        <div>Requerido: <span class="font-semibold"><?php echo e(number_format($req)); ?></span></div>
                        <div class="flex items-center justify-center gap-2">
                            <span class="inline-block w-3 h-3 rounded-full bg-green-600"></span>
                            Registrado:
                            <span class="font-semibold"><?php echo e(number_format($reg)); ?></span>
                            <span class="text-gray-500">(<?php echo e($regPct); ?>%)</span>
                        </div>
                        <div class="flex items-center justify-center gap-2">
                            <span class="inline-block w-3 h-3 rounded-full bg-red-600"></span>
                            Restante:
                            <span class="font-semibold"><?php echo e(number_format($rest)); ?></span>
                            <span class="text-gray-500">(<?php echo e($restPct); ?>%)</span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
<div class="col-span-full bg-white rounded-xl shadow p-6">
  <div class="flex items-center justify-between mb-3">
    <h3 class="text-lg font-semibold">Alcance por provincia (%)</h3>
    <span class="text-xs text-gray-500">0 a 100</span>
  </div>
  <div class="h-72">
    <canvas id="barsPct"></canvas>
  </div>
</div>
 <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-3">
        
        <div class="lg:col-span-3 grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            <div class="bg-white rounded-xl shadow p-6">
                <h3 class="text-lg font-semibold mb-3">Avance de meta (a la fecha -
                    <?php echo e(\Carbon\Carbon::now()->format('d/m/Y')); ?>)</h3>
                <div class="flex items-center gap-6">
                    <div class="w-40 h-40">
                        <canvas id="donut"></canvas>
                    </div>
                    <div class="flex-1">
                        <ul class="text-sm space-y-2">
                            <li class="flex items-center justify-between">
                                <span class="text-gray-600">Cumplido</span>
                                <span class="font-semibold">
                                    <?php echo e(number_format($cumplidoPct, 2)); ?>%
                                    <span
                                        class="text-xs text-gray-500">(<?php echo e(number_format($acumulado)); ?>/<?php echo e(number_format($metaTotal)); ?>)</span>
                                </span>
                            </li>
                            <li class="flex items-center justify-between">
                                <span class="text-gray-600">Pendiente</span>
                                <span class="font-semibold">
                                    <?php echo e(number_format($pendientePct, 2)); ?>%
                                    <span
                                        class="text-xs text-gray-500">(<?php echo e(number_format($pendienteAbs)); ?>/<?php echo e(number_format($metaTotal)); ?>)</span>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-xl shadow p-6">
                <div class="flex items-center justify-between mb-3">
                    <h3 class="text-lg font-semibold">Registros por usuario</h3>
                    <span class="text-xs text-gray-500">Hoy (<?php echo e(\Carbon\Carbon::now()->format('d/m/Y')); ?>) y acumulado
                    </span>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full text-xs sm:text-sm">
                        <thead class="bg-slate-100">
                            <tr>
                                <th class="px-3 py-2 text-left">Usuario</th>
                                <th class="px-3 py-2 text-right">Total diario</th>
                                <th class="px-3 py-2 text-right">Total general</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $usuariosResumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-t">
                                    <td class="px-3 py-2"><?php echo e($u->usuario); ?></td>
                                    <td class="px-3 py-2 text-right"><?php echo e(number_format($u->total_diario)); ?></td>
                                    <td class="px-3 py-2 text-right font-semibold"><?php echo e(number_format($u->total_general)); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="px-3 py-6 text-center text-gray-500">Sin registros</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-span-full bg-white rounded-xl shadow p-6 mt-6 grid grid-cols-2 lg:grid-cols-2 gap-6">
            
            <div class="bg-white rounded-xl shadow p-6">
                <h3 class="text-lg font-semibold mb-3">Registrados por PROVINCIA (totales)</h3>
                <div class="overflow-x-auto max-h-[420px]">
                    <table class="min-w-full text-xs sm:text-sm">
                        <thead class="bg-slate-100">
                            <tr>
                                <th class="px-3 py-2 text-left">Provincia</th>
                                <th class="px-3 py-2 text-right">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                // Ordenar desc por total
                                $provTablaOrdenada = collect($provTabla)->sortByDesc('total');
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $provTablaOrdenada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-t">
                                    <td class="px-3 py-2"><?php echo e($row['provincia']); ?></td>
                                    <td class="px-3 py-2 text-right"><?php echo e(number_format($row['total'])); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2" class="px-3 py-6 text-center text-gray-500">Sin datos</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="bg-white rounded-xl shadow p-6">
                <h3 class="text-lg font-semibold mb-3">Registrados por MUNICIPIO (totales)</h3>
                <div class="overflow-x-auto max-h-[520px]">
                    <table class="min-w-full text-xs sm:text-sm">
                        <thead class="bg-slate-100">
                            <tr>
                                <th class="px-3 py-2 text-left">Municipio</th>
                                <th class="px-3 py-2 text-right">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $munTabla; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-t">
                                    <td class="px-3 py-2"><?php echo e($row->municipio ?? '-'); ?></td>
                                    <td class="px-3 py-2 text-right"><?php echo e(number_format($row->total ?? 0)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2" class="px-3 py-6 text-center text-gray-500">Sin datos</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="col-span-full bg-white rounded-xl shadow p-6">
            <div class="flex items-center justify-between mb-3">
                <h3 class="text-lg font-semibold">Totales por provincia</h3>
                <span class="text-xs text-gray-500">Acumulado (registros)</span>
            </div>
            <div class="h-72">
                <canvas id="bars"></canvas>
            </div>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php $__currentLoopData = $piesExcel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                (function() {
                    const id = 'pie-<?php echo e(\Illuminate\Support\Str::slug($p['provincia'], '-')); ?>';
                    const el = document.getElementById(id);
                    if (!el) return;
                    const prev = Chart.getChart(el);
                    if (prev) prev.destroy();

                    new Chart(el, {
                        type: 'pie',
                        data: {
                            labels: ['Registrado', 'Restante'],
                            datasets: [{
                                data: [<?php echo e((int) $p['registrado']); ?>,
                                    <?php echo e((int) $p['pendiente']); ?>],
                                backgroundColor: ['#16a34a', '#dc2626'],
                            }]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    display: false
                                },
                                tooltip: {
                                    callbacks: {
                                        label: (ctx) => {
                                            const total = <?php echo e((int) $p['requerido']); ?>;
                                            const val = ctx.parsed || 0;
                                            const pct = total > 0 ? Math.round((val / total) *
                                                100) + '%' : '0%';
                                            return ` ${ctx.label}: ${val.toLocaleString()} (${pct})`;
                                        }
                                    }
                                },
                                datalabels: {
                                    color: '#fff',
                                    font: {
                                        weight: 'bold'
                                    },
                                    formatter: (value, ctx) => {
                                        const total = <?php echo e((int) $p['requerido']); ?>;
                                        const pct = total > 0 ? Math.round((value / total) * 100) :
                                            0;
                                        return pct ? pct + '%' : '';
                                    }
                                }
                            }
                        },
                        plugins: [ChartDataLabels]
                    });
                })();
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>
    <script>
        // ===== BARRAS: Totales por provincia =====
        (function initBars() {
            const el = document.getElementById('bars');
            const prev = Chart.getChart(el);
            if (prev) prev.destroy();
            const ctx = el.getContext('2d');

            const labels = <?php echo json_encode($provLabels, 15, 512) ?>;
            const data = <?php echo json_encode($provTotals, 15, 512) ?>;
            const suggestedMax = <?php echo json_encode($provSuggested, 15, 512) ?>;

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels,
                    datasets: [{
                        label: 'Total registrados',
                        data
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            suggestedMax: suggestedMax
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'top'
                        },
                        tooltip: {
                            callbacks: {
                                label: (ctx) => ` ${Number(ctx.parsed.y).toLocaleString()}`
                            }
                        }
                    }
                }
            });
        })();

        // ===== DONUT: Avance global =====
        (function initDonut() {
            const el = document.getElementById('donut');
            const prev = Chart.getChart(el);
            if (prev) prev.destroy();
            const ctx = el.getContext('2d');

            const dataPct = [<?php echo json_encode($cumplidoPct, 15, 512) ?>, <?php echo json_encode($pendientePct, 15, 512) ?>];
            const abs = {
                cumplido: <?php echo json_encode($acumulado, 15, 512) ?>,
                pendiente: <?php echo json_encode($pendienteAbs, 15, 512) ?>,
                meta: <?php echo json_encode($metaTotal, 15, 512) ?>
            };

            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Cumplido', 'Pendiente'],
                    datasets: [{
                        data: dataPct
                    }]
                },
                options: {
                    cutout: '65%',
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: (context) => {
                                    const label = context.label || '';
                                    const valPct = context.parsed;
                                    const valAbs = label === 'Cumplido' ? abs.cumplido : abs.pendiente;
                                    return ` ${label}: ${valPct}% (${valAbs.toLocaleString()}/${abs.meta.toLocaleString()})`;
                                }
                            }
                        }
                    }
                }
            });
        })();
    </script>
    <script>
  (function initBarsPct(){
    const el = document.getElementById('barsPct');
    const prev = Chart.getChart(el); if (prev) prev.destroy();
    const ctx = el.getContext('2d');

    const labels = <?php echo json_encode($provLabels, 15, 512) ?>;   // ['Cercado', ...]
    const data   = <?php echo json_encode($provPct, 15, 512) ?>;      // [0..100 por provincia]

    new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Alcance (%)',
          data,
          backgroundColor: '#3b82f6'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: { beginAtZero: true, max: 100, ticks: { callback: v => v + '%' } }
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (ctx) => ` ${ctx.parsed.y}%`
            }
          },
          datalabels: {
            anchor: 'end',
            align: 'end',
            color: '#111',
            font: { weight: 'bold' },
            formatter: (value) => value + '%'
          }
        }
      },
      plugins: [ChartDataLabels]
    });
  })();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROYECTOS\urus-o\resources\views/dashboard.blade.php ENDPATH**/ ?>